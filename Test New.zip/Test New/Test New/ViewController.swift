//
//  ViewController.swift
//  Test New
//
//  Created by Ninder chand on 04/12/22.
//

import UIKit
import SDWebImage

class ViewController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    
    
    var newsData: [Post] = []
    
    var page: Int = Int()
  
   var namelbl = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        
        
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.collectionViewLayout = UICollectionViewFlowLayout()
       
       
        
       
        let layout = collectionView?.collectionViewLayout as! UICollectionViewFlowLayout
                layout.itemSize = UICollectionViewFlowLayout.automaticSize
                layout.estimatedItemSize = CGSize(width: view.frame.width-20, height: 40)
        

        self.fetchPostData { (posts) in
        self.newsData = posts }
        
        
        
        // Do any additional setup after loading the view.
    }

   
    
   
    
   


}

extension ViewController: UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return newsData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieCollectionViewCell", for: indexPath) as! MovieCollectionViewCell
            
            cell.setup(with: newsData[indexPath.row])
            return cell
        }
    
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if indexPath.row == self.newsData.count - 1 {  //numberofitem count
                updateNextSet()
            }
    }

    func updateNextSet(){
       self.fetchPostData { (posts) in
           self.newsData += posts
              
                   }
}
    
    
    func fetchPostData(completionHandler: @escaping ([Post]) -> Void ) {
       
        self.page += 1
          let url = URL(string: "https://www.sikhnama.com/wp-json/wp/v2/posts/?categories=5&page=\(page)")!
          
          let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
              
              guard let data = data else {return}
              
              do {
                  
                  let postsData = try JSONDecoder().decode([Post].self, from: data)
                  
                  completionHandler(postsData)
                  DispatchQueue.main.async {
                      self.collectionView.reloadData()
                      
                  }
              }
              
              catch {
                  
                  let error = error
                  print(String(describing: error))
              }
              
              
              
          }
        task.resume()
          
          
          
          
          
          
      }
    
   
    
}

extension ViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        var returnValue = CGSize()
        
        if UIScreen.main.bounds.size.height > 960{ //Write iPhone or iPad size. If iPad :
                     returnValue = CGSize(width: (((view.frame.width) - 40) / 2), height: 200)
                   } else { //if iPhone
                     returnValue = CGSize(width: view.frame.width-20 , height: 200)
                   }
                   
        return returnValue
    }
    
}

extension ViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
      
      
       
        
    }
}














