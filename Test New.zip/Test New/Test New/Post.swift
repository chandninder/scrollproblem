//
//  Post.swift
//  Test New
//
//  Created by Ninder chand on 04/12/22.
//

import Foundation




struct Rendered: Codable {
     var rendered: String
    
}

struct Root: Codable {
    let images: [Image]
}

struct Image: Codable {
    let mediumIMG: String
    
    enum CodingKeys: String, CodingKey {
        case mediumIMG = "medium"
        
    }
    
}
    



struct Post: Codable{
    
    var id: Int!
    var title: Rendered!
    var content: Rendered!
    var link: String!
    var post_views: Int!
    
    
    
}


