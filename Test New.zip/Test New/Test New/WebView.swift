//
//  WebView.swift
//  Test New
//
//  Created by Ninder chand on 05/12/22.
//

import UIKit
import WebKit
import SVProgressHUD

class WebView: UIViewController, WKUIDelegate, WKNavigationDelegate, UIScrollViewDelegate {

    @IBOutlet weak var webView: WKWebView!
    
    @IBOutlet weak var conTitle: UILabel!
    
    @IBOutlet weak var scroll: UIScrollView!
    
    @IBOutlet weak var heightWeb: NSLayoutConstraint!
    
    var webContent = ""
    var webTitle = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        webView.navigationDelegate = self
        
        self.webView.scrollView.isScrollEnabled = false
        
      
        DispatchQueue.main.asyncAfter(deadline: .now()) {
                    SVProgressHUD.show()
                }
        
        let htmlString:String = "<html><head><style type=\"text/css\"> body {font-family: \"SFUIText-Regular\"; text-align: center; font-size: 38; line-height:55px; } img { max-width: 100%; width: auto; height: auto; } iframe { max-width: auto; width: auto; height: auto; }</style> </head><body>"+webContent+"</body></html>"

              self.webView.loadHTMLString(htmlString, baseURL: nil)
        
        conTitle.text = webTitle
        
       

        // Do any additional setup after loading the view.
    }
    
    
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        print("Start loading")
        
      
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("End loading")
        
        SVProgressHUD.dismiss()
                
       
        
       
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.webView.evaluateJavaScript("document.readyState", completionHandler: { (complete, error) in
                if complete != nil {
                    self.webView.evaluateJavaScript("document.body.scrollHeight", completionHandler: { (height, error) in
                       self.heightWeb.constant = webView.scrollView.contentSize.height
                       
                       
                    })
                }
            })
            
        }
       
        
      
            
        }
        
        
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
